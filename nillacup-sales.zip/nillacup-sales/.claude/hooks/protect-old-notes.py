#!/usr/bin/env python3
"""PreToolUse hook: block edits to notes.md of past meetings (history stays fixed).
Set ALLOW_EDIT_OLD_NOTES=1 to override for a deliberate correction."""
import json, os, re, sys, datetime

try:
    data = json.load(sys.stdin)
except Exception:
    sys.exit(0)

path = (data.get("tool_input") or {}).get("file_path", "") or ""
m = re.search(r"meetings/(\d{4}-\d{2}-\d{2})[^/]*/notes\.md$", path.replace("\\", "/"))
if not m or os.environ.get("ALLOW_EDIT_OLD_NOTES") == "1":
    sys.exit(0)

try:
    folder_date = datetime.date.fromisoformat(m.group(1))
except ValueError:
    sys.exit(0)

if folder_date < datetime.date.today() and os.path.exists(path):
    sys.stderr.write(
        "صورت‌جلسهٔ جلسهٔ گذشته قفل است. اصلاحیه را در جلسهٔ جدید ثبت کن "
        "یا برای اصلاح عمدی ALLOW_EDIT_OLD_NOTES=1 را تنظیم کن.\n"
    )
    sys.exit(2)
sys.exit(0)
